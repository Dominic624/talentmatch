/**
 * Seeds realistic demo data. Safe to re-run: it wipes existing data first.
 * Demo logins (password for all: Demo@123):
 *   client@demo.com · freelancer@demo.com · admin@demo.com
 */
const { db, tx } = require('./db');
const { hashPassword } = require('./auth');
const { scoreMatch } = require('./matching');

const PASSWORD = 'Demo@123';
const hash = hashPassword(PASSWORD);
const day = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const ts = (n) => new Date(Date.now() + n * 864e5).toISOString().replace('T', ' ').slice(0, 19);

const freelancers = [
  ['Priya Raman', 'freelancer@demo.com', 'Full-stack developer', 'Chennai', 1200, 1, ['React', 'Next.js', 'Node.js', 'MongoDB', 'Tailwind CSS', 'Shopify'], 'Seven years shipping SaaS products and storefronts for startups.'],
  ['Arjun Kumar', 'arjun@demo.com', 'UI/UX designer', 'Bengaluru', 1000, 1, ['Figma', 'Design systems', 'Prototyping', 'Shopify', 'User research'], 'Design-first, with reusable component libraries and clean handoff.'],
  ['Sneha Nair', 'sneha@demo.com', 'Data engineer', 'Kochi', 1100, 1, ['Python', 'SQL', 'Recharts', 'React', 'Data visualization'], 'Turns messy data into dashboards teams actually use.'],
  ['Rohit Mehta', 'rohit@demo.com', 'SEO specialist', 'Mumbai', 700, 1, ['SEO', 'Content strategy', 'Analytics', 'Copywriting'], 'Organic growth for D2C and SaaS brands.'],
  ['Karan Shah', 'karan@demo.com', 'Frontend developer', 'Pune', 900, 1, ['React', 'Next.js', 'Tailwind CSS', 'TypeScript'], 'Pixel-perfect frontends with strong accessibility habits.'],
  ['Meera Iyer', 'meera@demo.com', 'Mobile developer', 'Hyderabad', 1300, 0, ['React Native', 'TypeScript', 'Firebase', 'Figma'], 'Cross-platform apps from prototype to store release.'],
  ['Vikram Singh', 'vikram@demo.com', 'Backend engineer', 'Delhi', 1250, 1, ['Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'Docker'], 'APIs, payments integrations and clean architecture.'],
  ['Ananya Das', 'ananya@demo.com', 'Brand designer', 'Kolkata', 800, 1, ['Branding', 'Logo design', 'Figma', 'Illustration'], 'Brand identities that feel distinct and hold up in print.'],
  ['Rahul Verma', 'rahul@demo.com', 'DevOps engineer', 'Noida', 1400, 1, ['Docker', 'AWS', 'CI/CD', 'Node.js'], 'Reliable pipelines and cost-aware cloud setups.'],
  ['Divya Menon', 'divya@demo.com', 'Content writer', 'Thiruvananthapuram', 500, 1, ['Copywriting', 'Content strategy', 'SEO'], 'Clear, human writing for technical products.'],
  ['Aditya Rao', 'aditya@demo.com', 'ML engineer', 'Bengaluru', 1600, 1, ['Python', 'Machine learning', 'NLP', 'SQL'], 'Applied ML: recommendations, ranking and search.'],
  ['Nisha Patel', 'nisha@demo.com', 'WordPress developer', 'Ahmedabad', 600, 1, ['WordPress', 'PHP', 'SEO', 'Shopify'], 'Fast, maintainable WordPress and WooCommerce builds.'],
];

const clients = [
  ['Aanya Sharma', 'client@demo.com', 'Kiwi Commerce'],
  ['Rajesh Gupta', 'rajesh@demo.com', 'FitTrack Labs'],
  ['Sara Khan', 'sara@demo.com', 'Bloom Analytics'],
  ['Dev Malhotra', 'dev@demo.com', 'Northwind Studio'],
];

const projects = [
  [0, 'E-commerce website redesign', 'Redesign our Shopify storefront to improve conversion. Includes a new product page, faster checkout flow and mobile-first layouts. Figma files will be shared.', ['React', 'Next.js', 'Tailwind CSS', 'Figma', 'Shopify'], 85000, 40],
  [0, 'Mobile app UI/UX for fitness startup', 'Design the full UI/UX for our workout tracking app: onboarding, plans, progress charts and a design system for the dev team.', ['Figma', 'Design systems', 'Prototyping', 'User research'], 60000, 30],
  [0, 'Data dashboard (React + Recharts)', 'Build an internal analytics dashboard with filters, drill-downs and exports. Data comes from a REST API we provide.', ['React', 'Recharts', 'Data visualization', 'SQL'], 45000, 25],
  [0, 'SEO and content strategy', 'Audit our site, build a six-month content plan and write the first ten cornerstone articles.', ['SEO', 'Content strategy', 'Copywriting'], 30000, 45],
  [0, 'Brand identity and logo pack', 'Logo, color palette, typography and a short brand guide for a new sustainable-packaging brand.', ['Branding', 'Logo design', 'Illustration'], 25000, 20],
  [1, 'React Native habit tracker MVP', 'Cross-platform MVP with auth, reminders and charts. Firebase backend.', ['React Native', 'TypeScript', 'Firebase'], 90000, 50],
  [1, 'Payments integration for subscriptions', 'Add subscription billing and invoices to our Node.js API, with webhooks and retries.', ['Node.js', 'Express', 'PostgreSQL'], 70000, 35],
  [2, 'Recommendation engine for course platform', 'Rank courses per learner using behavior data. Needs offline evaluation and a simple API.', ['Python', 'Machine learning', 'SQL'], 120000, 60],
  [2, 'CI/CD and Docker setup', 'Containerize three services and set up GitHub Actions with staging and production deploys.', ['Docker', 'CI/CD', 'AWS'], 55000, 21],
  [3, 'WooCommerce store speed optimization', 'Cut load times on a slow WooCommerce store and fix Core Web Vitals.', ['WordPress', 'PHP', 'SEO'], 28000, 14],
];

function run() {
  tx(() => {
    ['notifications', 'reviews', 'messages', 'transactions', 'milestones', 'contracts', 'proposals', 'projects', 'users']
      .forEach((t) => db.exec(`DELETE FROM ${t}`));
    db.exec(`DELETE FROM sqlite_sequence`);

    const addUser = db.prepare(
      `INSERT INTO users (role, name, email, password_hash, headline, bio, location, rate, available, skills, company) VALUES (?,?,?,?,?,?,?,?,?,?,?)`
    );
    addUser.run('admin', 'Admin', 'admin@demo.com', hash, 'Platform admin', '', '', 0, 1, '[]', 'TalentMatch');
    const fid = {};
    freelancers.forEach(([name, email, headline, loc, rate, avail, skills, bio]) => {
      fid[email] = Number(addUser.run('freelancer', name, email, hash, headline, bio, loc, rate, avail, JSON.stringify(skills), '').lastInsertRowid);
    });
    const cid = clients.map(([name, email, company]) =>
      Number(addUser.run('client', name, email, hash, '', '', '', 0, 1, '[]', company).lastInsertRowid));

    const addProject = db.prepare('INSERT INTO projects (client_id, title, description, skills, budget, deadline, created_at) VALUES (?,?,?,?,?,?,?)');
    const pid = projects.map(([ci, title, desc, skills, budget, days], i) =>
      Number(addProject.run(cid[ci], title, desc, JSON.stringify(skills), budget, day(days), ts(-12 + i)).lastInsertRowid));

    // proposals: each freelancer bids on projects where at least one skill overlaps
    const addProposal = db.prepare('INSERT INTO proposals (project_id, freelancer_id, cover, bid, weeks, score, status, created_at) VALUES (?,?,?,?,?,?,?,?)');
    const fRows = db.prepare(`SELECT * FROM users WHERE role='freelancer'`).all();
    const pRows = db.prepare('SELECT * FROM projects').all();
    let n = 0;
    pRows.forEach((p) => {
      const proj = { ...p, skills: JSON.parse(p.skills) };
      fRows.forEach((f) => {
        const fu = { ...f, skills: JSON.parse(f.skills), available: !!f.available };
        const m = scoreMatch(proj, fu, {});
        if (m.matchedSkills.length === 0) return;
        if (p.id === 1 && f.email === 'freelancer@demo.com') return; // contract holder handled below
        const bid = Math.round((p.budget * (0.82 + ((n * 7) % 15) / 100)) / 500) * 500;
        addProposal.run(p.id, f.id, `Hi, I've read your brief for "${p.title}". I have delivered similar work and can start this week. I would begin with a short discovery call, then share a milestone plan.`,
          bid, 3 + (n % 5), m.score, 'new', ts(-8 + (n % 6)));
        n++;
      });
    });

    // Contract 1: in-progress project with Priya (the demo freelancer) on project #1
    const priya = fid['freelancer@demo.com'];
    db.prepare('INSERT INTO proposals (project_id, freelancer_id, cover, bid, weeks, score, status, created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(pid[0], priya, 'I have shipped three Shopify storefront redesigns. I would start with a conversion audit, then deliver wireframes in week one.', 85000, 6, 96, 'hired', ts(-9));
    db.prepare(`UPDATE proposals SET status='rejected' WHERE project_id=? AND freelancer_id != ?`).run(pid[0], priya);
    db.prepare(`UPDATE projects SET status='in_progress' WHERE id=?`).run(pid[0]);
    const c1 = Number(db.prepare('INSERT INTO contracts (project_id, client_id, freelancer_id, total, created_at) VALUES (?,?,?,?,?)').run(pid[0], cid[0], priya, 85000, ts(-8)).lastInsertRowid);
    const addM = db.prepare('INSERT INTO milestones (contract_id, position, title, amount, status, deliverable) VALUES (?,?,?,?,?,?)');
    const m1 = Number(addM.run(c1, 1, 'Design and wireframes', 25000, 'paid', 'Figma file with 12 wireframes and style guide').lastInsertRowid);
    const m2 = Number(addM.run(c1, 2, 'Frontend build', 40000, 'submitted', 'Staging link: https://staging.example.com — product page and checkout flow ready for review').lastInsertRowid);
    addM.run(c1, 3, 'Testing and launch', 20000, 'pending', '');
    const addT = db.prepare('INSERT INTO transactions (contract_id, milestone_id, type, amount, created_at) VALUES (?,?,?,?,?)');
    addT.run(c1, m1, 'escrow_deposit', 25000, ts(-7));
    addT.run(c1, m1, 'escrow_release', 25000, ts(-4));
    addT.run(c1, m2, 'escrow_deposit', 40000, ts(-3));

    // Contract 2: fully completed, so reviews and the earnings chart have data
    const arjun = fid['arjun@demo.com'];
    db.prepare('INSERT INTO proposals (project_id, freelancer_id, cover, bid, weeks, score, status, created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(pid[4], arjun, 'Brand work is my specialty; I will deliver three logo directions then refine one.', 25000, 3, 78, 'hired', ts(-40));
    db.prepare(`UPDATE projects SET status='completed' WHERE id=?`).run(pid[4]);
    const c2 = Number(db.prepare(`INSERT INTO contracts (project_id, client_id, freelancer_id, total, status, created_at) VALUES (?,?,?,?, 'completed', ?)`).run(pid[4], cid[0], arjun, 25000, ts(-38)).lastInsertRowid);
    const m3 = Number(addM.run(c2, 1, 'Logo directions', 10000, 'paid', 'Three directions delivered').lastInsertRowid);
    const m4 = Number(addM.run(c2, 2, 'Final brand guide', 15000, 'paid', 'Brand guide PDF').lastInsertRowid);
    addT.run(c2, m3, 'escrow_deposit', 10000, ts(-37)); addT.run(c2, m3, 'escrow_release', 10000, ts(-33));
    addT.run(c2, m4, 'escrow_deposit', 15000, ts(-30)); addT.run(c2, m4, 'escrow_release', 15000, ts(-24));
    const addR = db.prepare('INSERT INTO reviews (contract_id, reviewer_id, reviewee_id, rating, comment, created_at) VALUES (?,?,?,?,?,?)');
    addR.run(c2, cid[0], arjun, 5, 'Excellent communication and the brand guide was thorough. Delivered ahead of schedule.', ts(-23));
    addR.run(c2, arjun, cid[0], 5, 'Clear brief, fast feedback and prompt payments. Would work together again.', ts(-23));

    // A few past reviews for other freelancers so ratings look realistic
    const extra = [['priya', 'freelancer@demo.com', 5, 'Priya rebuilt our checkout flow and conversion went up. Very professional.'],
      ['priya', 'freelancer@demo.com', 5, 'Great engineer, communicates clearly and hits deadlines.'],
      ['priya', 'freelancer@demo.com', 4, 'Solid work. A couple of revisions needed but handled quickly.'],
      ['karan', 'karan@demo.com', 5, 'Fast and tidy frontend work.'],
      ['sneha', 'sneha@demo.com', 5, 'The dashboard is exactly what we needed.'],
      ['vikram', 'vikram@demo.com', 4, 'Reliable backend developer.'],
      ['aditya', 'aditya@demo.com', 5, 'Our ranking quality improved noticeably.']];
    extra.forEach(([, email, rating, comment], i) => {
      const dummy = Number(db.prepare('INSERT INTO contracts (project_id, client_id, freelancer_id, total, status, created_at) VALUES (?,?,?,?,?,?)')
        .run(pid[(i + 5) % pid.length], cid[(i % 3) + 1], fid[email], 20000, 'completed', ts(-90 + i)).lastInsertRowid);
      addR.run(dummy, cid[(i % 3) + 1], fid[email], rating, comment, ts(-60 + i));
    });

    // Messages on project #1 between Aanya and Priya
    const addMsg = db.prepare('INSERT INTO messages (project_id, sender_id, recipient_id, body, created_at) VALUES (?,?,?,?,?)');
    addMsg.run(pid[0], priya, cid[0], 'Hi Aanya! Wireframes are approved, I am starting the frontend build now.', ts(-6));
    addMsg.run(pid[0], cid[0], priya, 'Great work. Please share the product page preview when ready.', ts(-6));
    addMsg.run(pid[0], priya, cid[0], 'Sure. The staging link is submitted with the milestone.', ts(-3));

    const addN = db.prepare('INSERT INTO notifications (user_id, text, link, created_at) VALUES (?,?,?,?)');
    addN.run(cid[0], '"Frontend build" was submitted for your review', `#/contract/${c1}`, ts(-3));
    addN.run(cid[0], 'New 92% match proposal from Karan Shah on "E-commerce website redesign"', `#/project/${pid[0]}`, ts(-5));
    addN.run(priya, 'Your milestone "Design and wireframes" was paid: ₹25,000', `#/contract/${c1}`, ts(-4));
  });
}

run();
const c = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
console.log(`Seeded ${c('users')} users, ${c('projects')} projects, ${c('proposals')} proposals, ${c('contracts')} contracts, ${c('reviews')} reviews.`);
console.log('Demo logins (password Demo@123): client@demo.com · freelancer@demo.com · admin@demo.com');

const path = require('path');
const express = require('express');
const { db, tx } = require('./db');
const { scoreMatch } = require('./matching');
const { hashPassword, verifyPassword, createToken, readToken, parseCookies } = require('./auth');

const app = express();
app.use(express.json({ limit: '100kb' }));

const RELEVANCE_THRESHOLD = 60;
const json = (s) => { try { return JSON.parse(s || '[]'); } catch { return []; } };
const str = (v, max = 2000) => String(v ?? '').trim().slice(0, max);
const int = (v) => Number.parseInt(v, 10);

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);
const forbidden = (m = 'You are not allowed to do that') => new HttpError(403, m);
const notFound = (m = 'Not found') => new HttpError(404, m);

// ---------- helpers ----------
function freelancerStats(id) {
  const r = db.prepare('SELECT AVG(rating) AS avg, COUNT(*) AS n FROM reviews WHERE reviewee_id = ?').get(id);
  const c = db.prepare(
    `SELECT COUNT(*) AS total, SUM(status = 'completed') AS completed FROM contracts WHERE freelancer_id = ?`
  ).get(id);
  return { avgRating: r.avg || 0, reviews: r.n, total: c.total, completed: c.completed || 0 };
}

function publicUser(u, withStats = true) {
  if (!u) return null;
  const out = {
    id: u.id, role: u.role, name: u.name, headline: u.headline, bio: u.bio, location: u.location,
    rate: u.rate, available: !!u.available, skills: json(u.skills), company: u.company,
  };
  if (withStats && u.role === 'freelancer') out.stats = freelancerStats(u.id);
  return out;
}

function projectRow(p) {
  const client = db.prepare('SELECT id, name, company FROM users WHERE id = ?').get(p.client_id);
  const proposals = db.prepare('SELECT COUNT(*) AS n FROM proposals WHERE project_id = ?').get(p.id).n;
  const contract = db.prepare('SELECT id FROM contracts WHERE project_id = ?').get(p.id);
  return { ...p, skills: json(p.skills), client, proposalCount: proposals, contractId: contract?.id || null };
}

function notify(userId, text, link = '') {
  db.prepare('INSERT INTO notifications (user_id, text, link) VALUES (?, ?, ?)').run(userId, text, link);
}

function loadProject(id) {
  const p = db.prepare('SELECT * FROM projects WHERE id = ?').get(int(id));
  if (!p) throw notFound('Project not found');
  return p;
}

function contractFor(id, user) {
  const c = db.prepare('SELECT * FROM contracts WHERE id = ?').get(int(id));
  if (!c) throw notFound('Contract not found');
  if (user.role !== 'admin' && c.client_id !== user.id && c.freelancer_id !== user.id) throw forbidden();
  return c;
}

// ---------- auth middleware ----------
app.use((req, _res, next) => {
  const token = parseCookies(req.headers.cookie).tm_token;
  const data = readToken(token);
  req.user = data ? db.prepare('SELECT * FROM users WHERE id = ?').get(data.id) || null : null;
  next();
});
const requireAuth = (req, _res, next) => (req.user ? next() : next(new HttpError(401, 'Please log in')));
const requireRole = (...roles) => (req, _res, next) =>
  roles.includes(req.user?.role) ? next() : next(forbidden(`Only ${roles.join(' / ')} accounts can do this`));

// wrap async-safe handlers so thrown HttpErrors reach the error middleware
const h = (fn) => (req, res, next) => { try { fn(req, res, next); } catch (e) { next(e); } };

function setSession(res, userId) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `tm_token=${createToken(userId)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=604800${secure}`);
}

// ---------- auth ----------
app.post('/api/auth/register', h((req, res) => {
  const { role, name, email, password } = req.body || {};
  if (!['client', 'freelancer'].includes(role)) throw bad('Choose client or freelancer');
  if (!str(name)) throw bad('Name is required');
  if (!/^\S+@\S+\.\S+$/.test(str(email))) throw bad('Enter a valid email');
  if (String(password || '').length < 8) throw bad('Password must be at least 8 characters');
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(str(email).toLowerCase())) throw bad('That email is already registered');

  const skills = Array.isArray(req.body.skills) ? req.body.skills.map((s) => str(s, 40)).filter(Boolean).slice(0, 20) : [];
  const info = db.prepare(
    `INSERT INTO users (role, name, email, password_hash, headline, bio, rate, skills, company)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(role, str(name, 80), str(email).toLowerCase(), hashPassword(password), str(req.body.headline, 120),
    str(req.body.bio), Math.max(0, int(req.body.rate) || 0), JSON.stringify(skills), str(req.body.company, 120));
  setSession(res, Number(info.lastInsertRowid));
  res.status(201).json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid)) });
}));

app.post('/api/auth/login', h((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email = ?').get(str(req.body?.email).toLowerCase());
  if (!u || !verifyPassword(String(req.body?.password || ''), u.password_hash)) throw new HttpError(401, 'Incorrect email or password');
  setSession(res, u.id);
  res.json({ user: publicUser(u) });
}));

app.post('/api/auth/logout', (_req, res) => {
  res.setHeader('Set-Cookie', 'tm_token=; HttpOnly; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => res.json({ user: req.user ? publicUser(req.user) : null }));

// ---------- users / reviews ----------
app.get('/api/users/:id', h((req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(int(req.params.id));
  if (!u) throw notFound('User not found');
  const reviews = db.prepare(
    `SELECT r.id, r.rating, r.comment, r.created_at, u.name AS reviewer
     FROM reviews r JOIN users u ON u.id = r.reviewer_id WHERE r.reviewee_id = ? ORDER BY r.id DESC`
  ).all(u.id);
  const breakdown = [5, 4, 3, 2, 1].map((star) => ({ star, count: reviews.filter((r) => r.rating === star).length }));
  res.json({ user: publicUser(u), reviews, breakdown });
}));

app.patch('/api/me', requireAuth, h((req, res) => {
  const b = req.body || {};
  const skills = Array.isArray(b.skills) ? b.skills.map((s) => str(s, 40)).filter(Boolean).slice(0, 20) : json(req.user.skills);
  db.prepare('UPDATE users SET headline = ?, bio = ?, rate = ?, available = ?, skills = ?, company = ? WHERE id = ?').run(
    str(b.headline ?? req.user.headline, 120), str(b.bio ?? req.user.bio), Math.max(0, int(b.rate ?? req.user.rate) || 0),
    b.available === undefined ? req.user.available : b.available ? 1 : 0, JSON.stringify(skills),
    str(b.company ?? req.user.company, 120), req.user.id
  );
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
}));

// ---------- projects ----------
app.get('/api/projects', requireAuth, h((req, res) => {
  const { q, skill, minBudget, maxBudget, status } = req.query;
  let rows = db.prepare('SELECT * FROM projects ORDER BY id DESC').all();
  if (req.user.role === 'client') rows = rows.filter((p) => p.client_id === req.user.id);
  else rows = rows.filter((p) => p.status === (status || 'open'));
  if (q) rows = rows.filter((p) => (p.title + ' ' + p.description).toLowerCase().includes(String(q).toLowerCase()));
  if (skill) rows = rows.filter((p) => json(p.skills).some((s) => s.toLowerCase() === String(skill).toLowerCase()));
  if (minBudget) rows = rows.filter((p) => p.budget >= int(minBudget));
  if (maxBudget) rows = rows.filter((p) => p.budget <= int(maxBudget));
  let out = rows.map(projectRow);
  if (req.user.role === 'freelancer') {
    const me = publicUser(req.user);
    out = out
      .map((p) => ({ ...p, match: scoreMatch(p, me, me.stats) }))
      .sort((a, b) => b.match.score - a.match.score);
  }
  res.json({ projects: out });
}));

app.post('/api/projects', requireAuth, requireRole('client'), h((req, res) => {
  const b = req.body || {};
  const skills = (Array.isArray(b.skills) ? b.skills : []).map((s) => str(s, 40)).filter(Boolean).slice(0, 15);
  if (str(b.title).length < 5) throw bad('Title must be at least 5 characters');
  if (str(b.description).length < 20) throw bad('Description must be at least 20 characters');
  if (!skills.length) throw bad('Add at least one required skill');
  if (!(int(b.budget) > 0)) throw bad('Enter a budget greater than 0');
  const info = db.prepare('INSERT INTO projects (client_id, title, description, skills, budget, deadline) VALUES (?, ?, ?, ?, ?, ?)')
    .run(req.user.id, str(b.title, 140), str(b.description), JSON.stringify(skills), int(b.budget), str(b.deadline, 20));
  res.status(201).json({ project: projectRow(db.prepare('SELECT * FROM projects WHERE id = ?').get(info.lastInsertRowid)) });
}));

app.get('/api/projects/:id', requireAuth, h((req, res) => {
  const p = projectRow(loadProject(req.params.id));
  const mine = db.prepare('SELECT * FROM proposals WHERE project_id = ? AND freelancer_id = ?').get(p.id, req.user.id);
  const out = { project: p, myProposal: mine || null };
  if (req.user.role === 'freelancer') {
    const me = publicUser(req.user);
    out.match = scoreMatch(p, me, me.stats);
  }
  res.json(out);
}));

// AI-ranked freelancers for a project (client only)
app.get('/api/projects/:id/matches', requireAuth, requireRole('client'), h((req, res) => {
  const p = projectRow(loadProject(req.params.id));
  if (p.client_id !== req.user.id) throw forbidden();
  const invited = new Set(db.prepare('SELECT freelancer_id FROM proposals WHERE project_id = ?').all(p.id).map((r) => r.freelancer_id));
  const matches = db.prepare(`SELECT * FROM users WHERE role = 'freelancer'`).all()
    .map((u) => {
      const pu = publicUser(u);
      return { freelancer: pu, hasProposed: invited.has(u.id), ...scoreMatch(p, pu, pu.stats) };
    })
    .filter((m) => m.matchedSkills.length > 0)
    .sort((a, b) => b.score - a.score);
  res.json({ project: p, matches });
}));

// Client invites a matched freelancer to apply
app.post('/api/projects/:id/invite', requireAuth, requireRole('client'), h((req, res) => {
  const p = loadProject(req.params.id);
  if (p.client_id !== req.user.id) throw forbidden();
  if (p.status !== 'open') throw bad('This project is no longer open');
  const f = db.prepare(`SELECT * FROM users WHERE id = ? AND role = 'freelancer'`).get(int(req.body?.freelancerId));
  if (!f) throw notFound('Freelancer not found');
  notify(f.id, `${req.user.name} invited you to apply for "${p.title}"`, `#/project/${p.id}`);
  res.json({ ok: true });
}));

// ---------- proposals ----------
app.post('/api/projects/:id/proposals', requireAuth, requireRole('freelancer'), h((req, res) => {
  const p = projectRow(loadProject(req.params.id));
  if (p.status !== 'open') throw bad('This project is no longer accepting proposals');
  const { cover, bid, weeks } = req.body || {};
  if (str(cover).length < 20) throw bad('Cover letter must be at least 20 characters');
  if (!(int(bid) > 0)) throw bad('Enter a bid greater than 0');
  if (!(int(weeks) > 0)) throw bad('Enter a timeline in weeks');
  if (db.prepare('SELECT 1 FROM proposals WHERE project_id = ? AND freelancer_id = ?').get(p.id, req.user.id)) {
    throw bad('You have already sent a proposal for this project');
  }
  const me = publicUser(req.user);
  const { score } = scoreMatch(p, me, me.stats);
  const info = db.prepare('INSERT INTO proposals (project_id, freelancer_id, cover, bid, weeks, score) VALUES (?, ?, ?, ?, ?, ?)')
    .run(p.id, req.user.id, str(cover), int(bid), int(weeks), score);
  if (score >= RELEVANCE_THRESHOLD) notify(p.client_id, `New ${score}% match proposal from ${req.user.name} on "${p.title}"`, `#/project/${p.id}`);
  res.status(201).json({ id: Number(info.lastInsertRowid), score });
}));

app.get('/api/projects/:id/proposals', requireAuth, requireRole('client'), h((req, res) => {
  const p = loadProject(req.params.id);
  if (p.client_id !== req.user.id) throw forbidden();
  const all = db.prepare(
    `SELECT pr.*, u.name, u.headline FROM proposals pr JOIN users u ON u.id = pr.freelancer_id WHERE pr.project_id = ? ORDER BY pr.score DESC, pr.id`
  ).all(p.id).map((r) => ({ ...r, stats: freelancerStats(r.freelancer_id) }));
  const showAll = req.query.all === '1';
  const relevant = all.filter((r) => r.score >= RELEVANCE_THRESHOLD);
  res.json({
    proposals: showAll ? all : relevant,
    total: all.length,
    relevant: relevant.length,
    hidden: all.length - relevant.length,
    threshold: RELEVANCE_THRESHOLD,
  });
}));

app.patch('/api/proposals/:id', requireAuth, requireRole('client'), h((req, res) => {
  const pr = db.prepare('SELECT * FROM proposals WHERE id = ?').get(int(req.params.id));
  if (!pr) throw notFound('Proposal not found');
  const p = loadProject(pr.project_id);
  if (p.client_id !== req.user.id) throw forbidden();
  const status = req.body?.status;
  if (!['shortlisted', 'rejected', 'new'].includes(status)) throw bad('Invalid status');
  if (pr.status === 'hired') throw bad('This proposal was already hired');
  db.prepare('UPDATE proposals SET status = ? WHERE id = ?').run(status, pr.id);
  if (status === 'shortlisted') notify(pr.freelancer_id, `You were shortlisted for "${p.title}"`, `#/project/${p.id}`);
  res.json({ ok: true });
}));

// Hire: creates the contract and its milestones
app.post('/api/proposals/:id/hire', requireAuth, requireRole('client'), h((req, res) => {
  const pr = db.prepare('SELECT * FROM proposals WHERE id = ?').get(int(req.params.id));
  if (!pr) throw notFound('Proposal not found');
  const p = loadProject(pr.project_id);
  if (p.client_id !== req.user.id) throw forbidden();
  if (p.status !== 'open') throw bad('This project already has a contract');

  const milestones = Array.isArray(req.body?.milestones) ? req.body.milestones : [];
  const clean = milestones.map((m) => ({ title: str(m.title, 120), amount: int(m.amount) })).filter((m) => m.title && m.amount > 0);
  if (!clean.length) throw bad('Add at least one milestone');
  const sum = clean.reduce((a, m) => a + m.amount, 0);
  if (sum !== pr.bid) throw bad(`Milestones total ₹${sum} but the agreed bid is ₹${pr.bid}`);

  const contractId = tx(() => {
    const c = db.prepare('INSERT INTO contracts (project_id, client_id, freelancer_id, total) VALUES (?, ?, ?, ?)')
      .run(p.id, p.client_id, pr.freelancer_id, pr.bid);
    const cid = Number(c.lastInsertRowid);
    const ins = db.prepare('INSERT INTO milestones (contract_id, position, title, amount) VALUES (?, ?, ?, ?)');
    clean.forEach((m, i) => ins.run(cid, i + 1, m.title, m.amount));
    db.prepare(`UPDATE proposals SET status = 'hired' WHERE id = ?`).run(pr.id);
    db.prepare(`UPDATE proposals SET status = 'rejected' WHERE project_id = ? AND id != ? AND status != 'rejected'`).run(p.id, pr.id);
    db.prepare(`UPDATE projects SET status = 'in_progress' WHERE id = ?`).run(p.id);
    return cid;
  });
  notify(pr.freelancer_id, `You were hired for "${p.title}"`, `#/contract/${contractId}`);
  res.status(201).json({ contractId });
}));

// ---------- contracts, milestones, payments ----------
function contractDetail(c) {
  const p = projectRow(db.prepare('SELECT * FROM projects WHERE id = ?').get(c.project_id));
  const milestones = db.prepare('SELECT * FROM milestones WHERE contract_id = ? ORDER BY position').all(c.id);
  const paid = milestones.filter((m) => m.status === 'paid').reduce((a, m) => a + m.amount, 0);
  const escrow = milestones.filter((m) => ['funded', 'submitted', 'approved'].includes(m.status)).reduce((a, m) => a + m.amount, 0);
  const transactions = db.prepare('SELECT * FROM transactions WHERE contract_id = ? ORDER BY id DESC').all(c.id);
  const client = publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(c.client_id), false);
  const freelancer = publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(c.freelancer_id), false);
  const reviews = db.prepare('SELECT reviewer_id, rating, comment FROM reviews WHERE contract_id = ?').all(c.id);
  return {
    contract: { ...c, project: p, client, freelancer },
    milestones, transactions, reviews,
    summary: { paid, escrow, remaining: c.total - paid - escrow, progress: Math.round((paid / c.total) * 100) },
  };
}

app.get('/api/contracts', requireAuth, h((req, res) => {
  const rows = db.prepare('SELECT * FROM contracts WHERE client_id = ? OR freelancer_id = ? ORDER BY id DESC').all(req.user.id, req.user.id);
  res.json({ contracts: rows.map((c) => {
    const d = contractDetail(c);
    return { ...d.contract, summary: d.summary };
  }) });
}));

app.get('/api/contracts/:id', requireAuth, h((req, res) => res.json(contractDetail(contractFor(req.params.id, req.user)))));

function milestoneAction(handler) {
  return h((req, res) => {
    const m = db.prepare('SELECT * FROM milestones WHERE id = ?').get(int(req.params.id));
    if (!m) throw notFound('Milestone not found');
    const c = contractFor(m.contract_id, req.user);
    handler(req, m, c);
    res.json(contractDetail(db.prepare('SELECT * FROM contracts WHERE id = ?').get(c.id)));
  });
}

// Client funds a milestone: money is held in escrow
app.post('/api/milestones/:id/fund', requireAuth, requireRole('client'), milestoneAction((req, m, c) => {
  if (c.client_id !== req.user.id) throw forbidden();
  if (m.status !== 'pending') throw bad('Only pending milestones can be funded');
  tx(() => {
    db.prepare(`UPDATE milestones SET status = 'funded' WHERE id = ?`).run(m.id);
    db.prepare(`INSERT INTO transactions (contract_id, milestone_id, type, amount) VALUES (?, ?, 'escrow_deposit', ?)`).run(c.id, m.id, m.amount);
  });
  notify(c.freelancer_id, `"${m.title}" is funded. You can start work.`, `#/contract/${c.id}`);
}));

// Freelancer submits deliverables
app.post('/api/milestones/:id/submit', requireAuth, requireRole('freelancer'), milestoneAction((req, m, c) => {
  if (c.freelancer_id !== req.user.id) throw forbidden();
  if (m.status !== 'funded') throw bad('The milestone must be funded before you can submit work');
  const note = str(req.body?.deliverable);
  if (note.length < 5) throw bad('Describe or link what you are delivering');
  db.prepare(`UPDATE milestones SET status = 'submitted', deliverable = ? WHERE id = ?`).run(note, m.id);
  notify(c.client_id, `"${m.title}" was submitted for your review`, `#/contract/${c.id}`);
}));

// Client approves: escrow is released to the freelancer
app.post('/api/milestones/:id/approve', requireAuth, requireRole('client'), milestoneAction((req, m, c) => {
  if (c.client_id !== req.user.id) throw forbidden();
  if (m.status !== 'submitted') throw bad('Only submitted milestones can be approved');
  tx(() => {
    db.prepare(`UPDATE milestones SET status = 'paid' WHERE id = ?`).run(m.id);
    db.prepare(`INSERT INTO transactions (contract_id, milestone_id, type, amount) VALUES (?, ?, 'escrow_release', ?)`).run(c.id, m.id, m.amount);
    const left = db.prepare(`SELECT COUNT(*) AS n FROM milestones WHERE contract_id = ? AND status != 'paid'`).get(c.id).n;
    if (left === 0) {
      db.prepare(`UPDATE contracts SET status = 'completed' WHERE id = ?`).run(c.id);
      db.prepare(`UPDATE projects SET status = 'completed' WHERE id = ?`).run(c.project_id);
    }
  });
  notify(c.freelancer_id, `₹${m.amount.toLocaleString('en-IN')} released for "${m.title}"`, `#/contract/${c.id}`);
}));

app.get('/api/contracts/:id/invoice', requireAuth, h((req, res) => {
  const d = contractDetail(contractFor(req.params.id, req.user));
  const lines = d.milestones.map((m) => `${String(m.position).padStart(2)}. ${m.title.padEnd(40)} ₹${String(m.amount).padStart(9)}  ${m.status}`);
  res.type('text/plain').send(
    `TALENTMATCH INVOICE — Contract #${d.contract.id}\nProject: ${d.contract.project.title}\n` +
    `Client: ${d.contract.client.name}\nFreelancer: ${d.contract.freelancer.name}\n\n${lines.join('\n')}\n\n` +
    `Total: ₹${d.contract.total}\nPaid: ₹${d.summary.paid}\nIn escrow: ₹${d.summary.escrow}\n`
  );
}));

// ---------- reviews ----------
app.post('/api/contracts/:id/reviews', requireAuth, h((req, res) => {
  const c = contractFor(req.params.id, req.user);
  if (c.status !== 'completed') throw bad('You can review once all milestones are paid');
  const rating = int(req.body?.rating);
  if (!(rating >= 1 && rating <= 5)) throw bad('Choose a rating from 1 to 5');
  if (db.prepare('SELECT 1 FROM reviews WHERE contract_id = ? AND reviewer_id = ?').get(c.id, req.user.id)) throw bad('You already reviewed this contract');
  const other = c.client_id === req.user.id ? c.freelancer_id : c.client_id;
  db.prepare('INSERT INTO reviews (contract_id, reviewer_id, reviewee_id, rating, comment) VALUES (?, ?, ?, ?, ?)')
    .run(c.id, req.user.id, other, rating, str(req.body?.comment, 1000));
  notify(other, `${req.user.name} left you a ${rating}★ review`, `#/contract/${c.id}`);
  res.status(201).json({ ok: true });
}));

// ---------- messaging (one thread per project + freelancer) ----------
function threadPeer(req) {
  const p = loadProject(req.params.id);
  if (req.user.role === 'client') {
    if (p.client_id !== req.user.id) throw forbidden();
    const fid = int(req.query.with ?? req.body?.with);
    if (!fid) throw bad('Choose who to message');
    const ok = db.prepare('SELECT 1 FROM proposals WHERE project_id = ? AND freelancer_id = ?').get(p.id, fid);
    if (!ok) throw forbidden('That freelancer has not applied to this project');
    return { project: p, peer: fid, freelancer: fid };
  }
  const ok = db.prepare('SELECT 1 FROM proposals WHERE project_id = ? AND freelancer_id = ?').get(p.id, req.user.id);
  if (!ok) throw forbidden('Send a proposal first to message the client');
  return { project: p, peer: p.client_id, freelancer: req.user.id };
}

app.get('/api/projects/:id/messages', requireAuth, h((req, res) => {
  const { project, peer, freelancer } = threadPeer(req);
  const rows = db.prepare(
    `SELECT m.id, m.sender_id, m.body, m.created_at FROM messages m
     WHERE m.project_id = ? AND ((m.sender_id = ? AND m.recipient_id = ?) OR (m.sender_id = ? AND m.recipient_id = ?))
     ORDER BY m.id`
  ).all(project.id, req.user.id, peer, peer, req.user.id);
  const who = publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(peer), false);
  res.json({ messages: rows, peer: who, freelancerId: freelancer });
}));

app.post('/api/projects/:id/messages', requireAuth, h((req, res) => {
  const { project, peer } = threadPeer(req);
  const body = str(req.body?.body, 2000);
  if (!body) throw bad('Message cannot be empty');
  db.prepare('INSERT INTO messages (project_id, sender_id, recipient_id, body) VALUES (?, ?, ?, ?)').run(project.id, req.user.id, peer, body);
  notify(peer, `New message from ${req.user.name} about "${project.title}"`, req.user.role === 'client' ? `#/project/${project.id}` : `#/project/${project.id}`);
  res.status(201).json({ ok: true });
}));

// ---------- notifications ----------
app.get('/api/notifications', requireAuth, (req, res) => {
  const items = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 30').all(req.user.id);
  res.json({ notifications: items, unread: items.filter((n) => !n.read).length });
});
app.post('/api/notifications/read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

// ---------- dashboard ----------
app.get('/api/dashboard', requireAuth, h((req, res) => {
  const u = req.user;
  if (u.role === 'client') {
    const projects = db.prepare('SELECT * FROM projects WHERE client_id = ? ORDER BY id DESC').all(u.id).map(projectRow);
    const contracts = db.prepare('SELECT * FROM contracts WHERE client_id = ?').all(u.id).map(contractDetail);
    const spent = contracts.reduce((a, c) => a + c.summary.paid, 0);
    const escrow = contracts.reduce((a, c) => a + c.summary.escrow, 0);
    const toApprove = contracts.flatMap((c) => c.milestones).filter((m) => m.status === 'submitted').length;
    const toFund = contracts.flatMap((c) => c.milestones).filter((m) => m.status === 'pending').length;
    const allProposals = db.prepare(
      `SELECT pr.score FROM proposals pr JOIN projects p ON p.id = pr.project_id WHERE p.client_id = ?`
    ).all(u.id);
    const relevant = allProposals.filter((r) => r.score >= RELEVANCE_THRESHOLD).length;
    // top recommended freelancers for the most recent open project
    const open = projects.find((p) => p.status === 'open');
    let recommended = [];
    if (open) {
      recommended = db.prepare(`SELECT * FROM users WHERE role = 'freelancer'`).all()
        .map((r) => { const pu = publicUser(r); return { freelancer: pu, projectId: open.id, ...scoreMatch(open, pu, pu.stats) }; })
        .filter((m) => m.matchedSkills.length).sort((a, b) => b.score - a.score).slice(0, 4);
    }
    return res.json({
      role: 'client', projects,
      stats: { activeProjects: projects.filter((p) => p.status !== 'completed').length, spent, escrow, pending: toApprove + toFund,
        proposalsReceived: allProposals.length, proposalsRelevant: relevant,
        noiseFiltered: allProposals.length ? Math.round(((allProposals.length - relevant) / allProposals.length) * 100) : 0 },
      recommended,
    });
  }
  if (u.role === 'freelancer') {
    const contracts = db.prepare('SELECT * FROM contracts WHERE freelancer_id = ?').all(u.id).map(contractDetail);
    const earned = contracts.reduce((a, c) => a + c.summary.paid, 0);
    const escrow = contracts.reduce((a, c) => a + c.summary.escrow, 0);
    const proposals = db.prepare(
      `SELECT pr.*, p.title FROM proposals pr JOIN projects p ON p.id = pr.project_id WHERE pr.freelancer_id = ? ORDER BY pr.id DESC`
    ).all(u.id);
    const me = publicUser(u);
    const recommended = db.prepare(`SELECT * FROM projects WHERE status = 'open' ORDER BY id DESC`).all().map(projectRow)
      .filter((p) => !proposals.some((pr) => pr.project_id === p.id))
      .map((p) => ({ ...p, match: scoreMatch(p, me, me.stats) })).sort((a, b) => b.match.score - a.match.score).slice(0, 5);
    // earnings by month for the chart
    const byMonth = {};
    db.prepare(`SELECT t.amount, t.created_at FROM transactions t JOIN contracts c ON c.id = t.contract_id WHERE t.type = 'escrow_release' AND c.freelancer_id = ?`)
      .all(u.id).forEach((t) => { const k = t.created_at.slice(0, 7); byMonth[k] = (byMonth[k] || 0) + t.amount; });
    return res.json({
      role: 'freelancer', me, recommended, proposals,
      contracts: contracts.map((c) => ({ ...c.contract, summary: c.summary })),
      stats: { earned, escrow, activeContracts: contracts.filter((c) => c.contract.status === 'active').length, proposalsSent: proposals.length },
      earnings: Object.entries(byMonth).map(([month, amount]) => ({ month, amount })),
    });
  }
  // admin
  const count = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  res.json({
    role: 'admin',
    stats: { users: count('users'), projects: count('projects'), proposals: count('proposals'), contracts: count('contracts') },
    users: db.prepare('SELECT id, role, name, email, created_at FROM users ORDER BY id DESC LIMIT 50').all(),
  });
}));

// ---------- static frontend + errors ----------
app.use('/api', (_req, _res, next) => next(notFound('Unknown API route')));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Something went wrong on our side. Please try again.' : err.message });
});

if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`TalentMatch running on http://localhost:${port}`));
}

module.exports = app;

/**
 * Matching engine.
 *
 * score (0-100) = 50% skill overlap
 *               + 15% budget fit
 *               + 15% rating
 *               + 10% past success rate
 *               + 10% availability
 *
 * This is a transparent weighted model (no external AI service needed), and each
 * result carries a plain-language "why" so users can see the reasoning.
 */
const WEIGHTS = { skills: 0.5, budget: 0.15, rating: 0.15, success: 0.1, availability: 0.1 };
const ASSUMED_HOURS = 60; // rough effort used to compare budget vs hourly rate

const norm = (s) => String(s).trim().toLowerCase();
const clamp = (n, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, n));

function scoreMatch(project, freelancer, stats = {}) {
  const needed = [...new Set(project.skills.map(norm))];
  const have = new Set(freelancer.skills.map(norm));
  const matched = needed.filter((s) => have.has(s));
  const skill = needed.length ? matched.length / needed.length : 0;

  const cost = Math.max(1, freelancer.rate) * ASSUMED_HOURS;
  const budget = freelancer.rate > 0 ? clamp(project.budget / cost) : 0.5;

  const rating = stats.avgRating ? clamp(stats.avgRating / 5) : 0.7; // neutral for newcomers
  const success = stats.total ? clamp(stats.completed / stats.total) : 0.8;
  const availability = freelancer.available ? 1 : 0.4;

  const total =
    WEIGHTS.skills * skill +
    WEIGHTS.budget * budget +
    WEIGHTS.rating * rating +
    WEIGHTS.success * success +
    WEIGHTS.availability * availability;

  const reasons = [];
  reasons.push(`Matches ${matched.length} of ${needed.length} required skills`);
  if (budget >= 0.9) reasons.push('fits your budget');
  else if (budget < 0.5) reasons.push('rate is above your budget');
  if (stats.avgRating >= 4.5) reasons.push(`rated ${stats.avgRating.toFixed(1)}★`);
  if (stats.total && stats.completed / stats.total >= 0.9) reasons.push('reliable delivery record');
  if (freelancer.available) reasons.push('available now');

  return {
    score: Math.round(total * 100),
    matchedSkills: matched,
    missingSkills: needed.filter((s) => !have.has(s)),
    why: reasons.join(' · '),
  };
}

module.exports = { scoreMatch, WEIGHTS };

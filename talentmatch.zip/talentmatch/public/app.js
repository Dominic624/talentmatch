/* TalentMatch single-page frontend (vanilla JS, hash router) */
'use strict';

const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
const initials = (n) => String(n || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
const when = (s) => (s ? new Date(String(s).replace(' ', 'T') + (String(s).includes('Z') ? '' : 'Z')).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : '');
const clock = (s) => new Date(String(s).replace(' ', 'T') + 'Z').toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

let me = null;
let timers = [];
let modalTimer = null;
const state = { tab: 'matches', showAll: false, filters: {} };

/* ---------- api / ui helpers ---------- */
async function api(url, opts = {}) {
  let res;
  try {
    res = await fetch('/api' + url, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : {},
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
  } catch {
    throw Object.assign(new Error('Cannot reach the server. Check your connection and try again.'), { network: true });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status });
  return data;
}

function toast(msg, bad = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (bad ? ' bad' : '');
  el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), 3800);
}

async function busy(btn, fn) {
  if (!btn || btn.disabled) return;
  const label = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span> ' + btn.textContent.trim();
  try { await fn(); } catch (e) { toast(e.message, true); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = label; } }
}

const ring = (n) => `<div class="ring ${n >= 90 ? 'hi' : ''}" style="--p:${n}" role="img" aria-label="${n}% match"><span>${n}%</span></div>`;
const tags = (skills = [], hits = []) => `<div class="tags">${skills.map((s) => `<span class="tag ${hits.map((h) => h.toLowerCase()).includes(s.toLowerCase()) ? 'hit' : ''}">${esc(s)}</span>`).join('')}</div>`;
const statusPill = (s) => {
  const map = { open: ['pri', 'Open'], in_progress: ['ok', 'In progress'], completed: ['', 'Completed'], cancelled: ['bad', 'Cancelled'], active: ['ok', 'Active'],
    new: ['pri', 'New'], shortlisted: ['ok', 'Shortlisted'], hired: ['ok', 'Hired'], rejected: ['bad', 'Not selected'],
    pending: ['', 'Pending'], funded: ['warn', 'Funded · in escrow'], submitted: ['warn', 'Submitted'], approved: ['ok', 'Approved'], paid: ['ok', 'Paid'] };
  const [c, t] = map[s] || ['', s];
  return `<span class="pill ${c}">${t}</span>`;
};
const empty = (ico, title, text, cta = '') => `<div class="empty"><div class="ico" aria-hidden="true">${ico}</div><b>${esc(title)}</b>${esc(text)}${cta ? `<div style="margin-top:14px">${cta}</div>` : ''}</div>`;
const skeleton = () => `<div class="grid g4"><div class="skeleton" style="height:112px"></div><div class="skeleton" style="height:112px"></div><div class="skeleton" style="height:112px"></div><div class="skeleton" style="height:112px"></div></div><div class="skeleton" style="height:300px;margin-top:16px"></div>`;
const stars = (n) => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));

/* ---------- shell ---------- */
function nav() {
  const items = me.role === 'client'
    ? [['#/', '▦', 'Dashboard'], ['#/new', '＋', 'Post a project'], ['#/projects', '▤', 'My projects'], ['#/contracts', '₹', 'Contracts']]
    : me.role === 'freelancer'
      ? [['#/', '▦', 'Dashboard'], ['#/projects', '◎', 'Find projects'], ['#/contracts', '₹', 'Contracts'], ['#/profile', '☺', 'My profile']]
      : [['#/', '▦', 'Dashboard']];
  const cur = location.hash || '#/';
  return items.map(([h, i, t]) => `<a href="${h}" class="${(h === '#/' ? cur === '#/' || cur === '' : cur.startsWith(h)) ? 'on' : ''}" ${cur === h ? 'aria-current="page"' : ''}><span aria-hidden="true">${i}</span>${t}</a>`).join('');
}

function shell(crumb, inner) {
  return `<div class="shell">
    <aside class="side">
      <a class="brand" href="#/"><span class="logo">T</span>TalentMatch</a>
      <nav class="nav" aria-label="Main">${nav()}</nav>
      <div class="saved"><small>Smart matching</small><b>Less noise</b><small>Only relevant proposals reach you</small></div>
    </aside>
    <div class="main-col">
      <header class="top">
        <div class="crumb">${crumb}</div>
        <div class="top-r">
          <button class="bell" data-act="bell" aria-label="Notifications">🔔<i id="bellN" hidden>0</i></button>
          <div id="drop" class="drop" hidden></div>
          <a href="${me.role === 'freelancer' ? '#/profile' : '#/'}" class="row" style="color:inherit"><span class="avatar sm">${esc(initials(me.name))}</span><span class="small" style="font-weight:600">${esc(me.name)}</span></a>
          <button class="btn ghost sm" data-act="logout">Log out</button>
        </div>
      </header>
      <main class="content" id="main">${inner}</main>
    </div>
  </div>`;
}

function mount(html) { $('#app').innerHTML = html; window.scrollTo(0, 0); }
function clearTimers() { timers.forEach(clearInterval); timers = []; }

async function refreshBell() {
  try {
    const d = await api('/notifications');
    const b = $('#bellN');
    if (b) { b.hidden = d.unread === 0; b.textContent = d.unread; }
  } catch { /* non-critical */ }
}

/* ---------- views ---------- */
async function viewAuth(mode = 'login') {
  const reg = mode === 'register';
  mount(`<div class="auth">
    <section class="hero">
      <a class="brand" href="#/login"><span class="logo">T</span>TalentMatch</a>
      <h1>Hire the right talent.<br>Get found for the right work.</h1>
      <p>AI matches freelancers and projects, so you skip the noise. Messaging, milestones and secure escrow-style payments in one place.</p>
      <div class="pills"><div><b>Smart</b>skill + budget matching</div><div><b>Escrow</b>milestone payments</div><div><b>Trust</b>two-way reviews</div></div>
    </section>
    <section class="auth-r"><div class="auth-card card" style="padding:28px">
      <div class="seg" role="tablist" style="width:100%;margin-bottom:22px">
        <button class="${!reg ? 'on' : ''}" style="flex:1" data-go="#/login" role="tab">Log in</button>
        <button class="${reg ? 'on' : ''}" style="flex:1" data-go="#/register" role="tab">Create account</button>
      </div>
      <h1 style="font-size:26px;font-weight:800">${reg ? 'Create your account' : 'Welcome back'}</h1>
      <p class="muted" style="margin:4px 0 20px">${reg ? 'Join as a client or a freelancer.' : 'Log in to continue to your dashboard.'}</p>
      <form data-form="${reg ? 'register' : 'login'}" novalidate>
        <div class="form-err" hidden></div>
        ${reg ? `<div class="field"><label>I am a</label><select name="role" id="roleSel"><option value="client">Client (I want to hire)</option><option value="freelancer">Freelancer (I want work)</option></select></div>
        <div class="field"><label for="name">Full name</label><input id="name" name="name" autocomplete="name" required></div>` : ''}
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" autocomplete="email" required></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" required>${reg ? '<div class="small muted" style="margin-top:4px">At least 8 characters</div>' : ''}</div>
        ${reg ? `<div id="fl-only" hidden><div class="field"><label for="skills">Skills (comma separated)</label><input id="skills" name="skills" placeholder="React, Node.js, Figma"></div>
        <div class="field"><label for="rate">Hourly rate (₹)</label><input id="rate" name="rate" type="number" min="0" placeholder="900"></div></div>` : ''}
        <button class="btn block" type="submit">${reg ? 'Create account' : 'Log in'}</button>
      </form>
      ${reg ? '' : `<div class="demo"><span class="small muted">Try a demo:</span>
        <button class="btn ghost sm" data-demo="client@demo.com">Client</button><button class="btn ghost sm" data-demo="freelancer@demo.com">Freelancer</button><button class="btn ghost sm" data-demo="admin@demo.com">Admin</button></div>`}
    </div></section></div>`);
  const sel = $('#roleSel');
  if (sel) sel.onchange = () => { $('#fl-only').hidden = sel.value !== 'freelancer'; };
}

async function viewDashboard() {
  mount(shell('Dashboard', skeleton()));
  const d = await api('/dashboard');
  if (d.role === 'client') return clientDashboard(d);
  if (d.role === 'freelancer') return freelancerDashboard(d);
  return adminDashboard(d);
}

function clientDashboard(d) {
  const s = d.stats;
  const body = `
    <div class="page-h"><div><h1>Hello, ${esc(me.name.split(' ')[0])} 👋</h1><p>Here is what needs your attention.</p></div><a class="btn" href="#/new">＋ New project</a></div>
    <div class="grid g4">
      <div class="card stat"><small>Active projects</small><b>${s.activeProjects}</b><span>${d.projects.length} total</span></div>
      <div class="card stat"><small>Total spend</small><b>${inr(s.spent)}</b><span>${inr(s.escrow)} in escrow</span></div>
      <div class="card stat"><small>Pending actions</small><b>${s.pending}</b><span style="color:var(--amber)">fund or approve milestones</span></div>
      <div class="card stat"><small>Proposal noise filtered</small><b>${s.noiseFiltered}%</b><span style="color:var(--green)">${s.proposalsRelevant} of ${s.proposalsReceived} are relevant</span></div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <section class="card"><h2>Your projects</h2><div class="stack">${d.projects.length ? d.projects.slice(0, 6).map(projectRowHtml).join('') : empty('📋', 'No projects yet', 'Post your first project and get AI-ranked freelancers instantly.', '<a class="btn" href="#/new">Post a project</a>')}</div></section>
      <section class="card"><h2>Recommended freelancers</h2><div class="stack">${d.recommended.length ? d.recommended.map((m) => `
        <div class="list-item"><div class="row"><span class="avatar">${esc(initials(m.freelancer.name))}</span>
          <div class="grow"><a href="#/user/${m.freelancer.id}" style="font-weight:700;color:inherit">${esc(m.freelancer.name)}</a><div class="small muted">${esc(m.freelancer.headline)}</div></div>${ring(m.score)}</div>
          <div style="margin:10px 0">${tags(m.freelancer.skills.slice(0, 4), m.matchedSkills)}</div>
          <button class="btn ghost sm" data-act="invite" data-project="${m.projectId}" data-f="${m.freelancer.id}">Invite to apply</button></div>`).join('')
        : empty('✨', 'No recommendations yet', 'Post an open project to see ranked matches.')}</div></section>
    </div>`;
  mount(shell('Dashboard', body));
}

function projectRowHtml(p) {
  return `<a class="list-item" href="#/project/${p.id}" style="display:block;color:inherit;text-decoration:none">
    <div class="row sp"><b>${esc(p.title)}</b>${statusPill(p.status)}</div>
    <div class="row small muted" style="margin-top:6px"><span>Budget ${inr(p.budget)}</span>·<span>${p.proposalCount} proposal${p.proposalCount === 1 ? '' : 's'}</span>${p.deadline ? `·<span>Due ${esc(p.deadline)}</span>` : ''}</div></a>`;
}

function freelancerDashboard(d) {
  const s = d.stats;
  const max = Math.max(1, ...d.earnings.map((e) => e.amount));
  const body = `
    <div class="page-h"><div><h1>Hello, ${esc(me.name.split(' ')[0])} 👋</h1><p>Projects picked for your skills.</p></div><a class="btn" href="#/projects">Browse all projects</a></div>
    <div class="grid g4">
      <div class="card stat"><small>Total earned</small><b>${inr(s.earned)}</b><span>released from escrow</span></div>
      <div class="card stat"><small>In escrow</small><b>${inr(s.escrow)}</b><span>secured for your work</span></div>
      <div class="card stat"><small>Active contracts</small><b>${s.activeContracts}</b><span>in progress</span></div>
      <div class="card stat"><small>Proposals sent</small><b>${s.proposalsSent}</b><span>${d.proposals.filter((p) => p.status === 'shortlisted').length} shortlisted</span></div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <section class="card"><h2>Recommended for you</h2><div class="stack">${d.recommended.length ? d.recommended.map((p) => `
        <a class="list-item" href="#/project/${p.id}" style="display:block;color:inherit;text-decoration:none"><div class="row">
          <div class="grow"><b>${esc(p.title)}</b><div class="small muted">${esc(p.client.company || p.client.name)} · Budget ${inr(p.budget)}</div><div style="margin:8px 0">${tags(p.skills, p.match.matchedSkills)}</div><div class="why">${esc(p.match.why)}</div></div>${ring(p.match.score)}</div></a>`).join('')
        : empty('🎯', 'Nothing new right now', 'We will notify you when a matching project is posted.')}</div></section>
      <div class="stack">
        <section class="card"><h2>Earnings</h2>${d.earnings.length ? `<div class="chart">${d.earnings.map((e) => `<div><span class="small" style="font-weight:700;color:var(--ink)">${inr(e.amount)}</span><i style="height:${Math.round((e.amount / max) * 100)}px"></i>${esc(e.month)}</div>`).join('')}</div>` : empty('💸', 'No earnings yet', 'Completed milestones show up here.')}</section>
        <section class="card"><h2>My proposals</h2><div class="stack">${d.proposals.length ? d.proposals.slice(0, 6).map((p) => `<a href="#/project/${p.project_id}" class="row sp" style="color:inherit"><span class="grow">${esc(p.title)}</span>${statusPill(p.status)}</a>`).join('') : empty('✉️', 'No proposals yet', 'Send your first proposal to a recommended project.')}</div></section>
      </div>
    </div>`;
  mount(shell('Dashboard', body));
}

function adminDashboard(d) {
  const body = `<div class="page-h"><div><h1>Admin overview</h1><p>Platform activity at a glance.</p></div></div>
    <div class="grid g4">${Object.entries(d.stats).map(([k, v]) => `<div class="card stat"><small style="text-transform:capitalize">${k}</small><b>${v}</b></div>`).join('')}</div>
    <section class="card" style="margin-top:16px"><h2>Recent users</h2><div style="overflow:auto"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead><tbody>
    ${d.users.map((u) => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td><span class="pill">${esc(u.role)}</span></td><td>${when(u.created_at)}</td></tr>`).join('')}</tbody></table></div></section>`;
  mount(shell('Admin', body));
}

async function viewNewProject() {
  if (me.role !== 'client') return forbiddenView();
  mount(shell('Projects / New', `
    <div class="page-h"><div><h1>Post a new project</h1><p>The more specific you are, the better the matches.</p></div></div>
    <div class="grid g2"><form class="card" data-form="project" novalidate>
      <div class="form-err" hidden></div>
      <div class="field"><label for="title">Project title</label><input id="title" name="title" placeholder="E-commerce website redesign" required></div>
      <div class="field"><label for="desc">Description</label><textarea id="desc" name="description" placeholder="What do you need built, and what does success look like?" required></textarea></div>
      <div class="field"><label for="sk">Required skills (comma separated)</label><input id="sk" name="skills" placeholder="React, Next.js, Figma" required></div>
      <div class="grid g2e"><div class="field"><label for="bud">Budget (₹)</label><input id="bud" name="budget" type="number" min="1" placeholder="85000" required></div>
      <div class="field"><label for="dl">Deadline</label><input id="dl" name="deadline" type="date"></div></div>
      <button class="btn" type="submit">Post project</button></form>
      <aside class="card" style="background:var(--primary-l);border-color:var(--primary-b);align-self:start"><h2 style="color:var(--primary)">✦ Tips for better matches</h2>
      <p class="muted">• List 4–6 core skills<br>• Set a realistic budget<br>• Describe the outcome, not just tasks<br>• You will define milestones when you hire</p></aside></div>`));
}

async function viewProjects() {
  mount(shell(me.role === 'client' ? 'My projects' : 'Find projects', skeleton()));
  const f = state.filters;
  const qs = new URLSearchParams(Object.entries(f).filter(([, v]) => v)).toString();
  const { projects } = await api('/projects' + (qs ? '?' + qs : ''));
  const isF = me.role === 'freelancer';
  const filters = isF ? `<form class="card row" data-form="filters" style="margin-bottom:16px;align-items:flex-end">
    <div class="grow"><label for="fq">Search</label><input id="fq" name="q" value="${esc(f.q || '')}" placeholder="Title or keyword"></div>
    <div><label for="fs">Skill</label><input id="fs" name="skill" value="${esc(f.skill || '')}" placeholder="React"></div>
    <div><label for="fmin">Min ₹</label><input id="fmin" name="minBudget" type="number" value="${esc(f.minBudget || '')}" style="width:110px"></div>
    <div><label for="fmax">Max ₹</label><input id="fmax" name="maxBudget" type="number" value="${esc(f.maxBudget || '')}" style="width:110px"></div>
    <button class="btn" type="submit">Apply</button><button class="btn ghost" type="button" data-act="clearfilters">Clear</button></form>` : '';
  const list = projects.length ? projects.map((p) => isF ? `
    <a class="list-item" href="#/project/${p.id}" style="display:block;color:inherit;text-decoration:none"><div class="row"><div class="grow"><b>${esc(p.title)}</b>
      <div class="small muted">${esc(p.client.company || p.client.name)} · Budget ${inr(p.budget)}${p.deadline ? ' · Due ' + esc(p.deadline) : ''}</div>
      <div style="margin:8px 0">${tags(p.skills, p.match.matchedSkills)}</div><div class="why">${esc(p.match.why)}</div></div>${ring(p.match.score)}</div></a>` : projectRowHtml(p)).join('')
    : empty('🔍', isF ? 'No projects match' : 'No projects yet', isF ? 'Try clearing the filters.' : 'Post your first project to get started.', isF ? '<button class="btn ghost" data-act="clearfilters">Clear filters</button>' : '<a class="btn" href="#/new">Post a project</a>');
  mount(shell(isF ? 'Find projects' : 'My projects', `<div class="page-h"><div><h1>${isF ? 'Find projects' : 'My projects'}</h1><p>${isF ? 'Ranked by how well they match you.' : 'All projects you have posted.'}</p></div>${isF ? '' : '<a class="btn" href="#/new">＋ New project</a>'}</div>${filters}<div class="stack">${list}</div>`));
}

async function viewProject(id) {
  mount(shell('Projects / …', skeleton()));
  const d = await api('/projects/' + id);
  const p = d.project;
  const head = `<div class="page-h"><div><h1>${esc(p.title)}</h1><p>${esc(p.client.company || p.client.name)} · Budget ${inr(p.budget)}${p.deadline ? ' · Due ' + esc(p.deadline) : ''} · ${statusPill(p.status)}</p></div>
    ${p.contractId && (me.role === 'client' || d.myProposal?.status === 'hired') ? `<a class="btn" href="#/contract/${p.contractId}">Open contract</a>` : ''}</div>`;
  if (me.role === 'client') {
    if (p.client.id !== me.id) return forbiddenView();
    return clientProject(p, head);
  }
  // freelancer view
  const mine = d.myProposal;
  const body = `${head}<div class="grid g2"><div class="stack">
    <section class="card"><h2>About this project</h2><p style="white-space:pre-wrap">${esc(p.description)}</p><div style="margin-top:14px">${tags(p.skills, d.match.matchedSkills)}</div></section>
    ${mine ? `<section class="card"><h2>Messages with the client</h2><div id="chat"></div></section>` : ''}</div>
    <div class="stack"><section class="card"><div class="row">${ring(d.match.score)}<div class="grow"><b>Your match</b><div class="small muted">${esc(d.match.why)}</div></div></div></section>
    <section class="card"><h2>${mine ? 'Your proposal' : 'Send a proposal'}</h2>${mine
      ? `<div class="row sp">${statusPill(mine.status)}<b>${inr(mine.bid)} · ${mine.weeks} wk</b></div><p class="muted" style="margin-top:10px;white-space:pre-wrap">${esc(mine.cover)}</p>`
      : p.status !== 'open' ? empty('🔒', 'Closed', 'This project is no longer accepting proposals.') : `<form data-form="proposal" data-project="${p.id}" novalidate><div class="form-err" hidden></div>
        <div class="field"><label for="cv">Cover letter</label><textarea id="cv" name="cover" placeholder="Why are you a great fit? What would you do first?"></textarea></div>
        <div class="grid g2e"><div class="field"><label for="bd">Bid (₹)</label><input id="bd" name="bid" type="number" min="1" value="${p.budget}"></div>
        <div class="field"><label for="wk">Weeks</label><input id="wk" name="weeks" type="number" min="1" value="4"></div></div>
        <button class="btn block" type="submit">Send proposal</button></form>`}</section></div></div>`;
  mount(shell('Projects / ' + esc(p.title), body));
  if (mine) startChat($('#chat'), p.id, null);
}

async function clientProject(p, head) {
  const tab = state.tab;
  const [m, pr] = await Promise.all([
    api(`/projects/${p.id}/matches`),
    api(`/projects/${p.id}/proposals${state.showAll ? '?all=1' : ''}`),
  ]);
  const matches = m.matches.length ? m.matches.map((x) => `
    <div class="list-item"><div class="row">${ring(x.score)}<span class="avatar">${esc(initials(x.freelancer.name))}</span>
      <div class="grow"><a href="#/user/${x.freelancer.id}" style="font-weight:700;color:inherit">${esc(x.freelancer.name)}</a>
      <div class="small muted">${esc(x.freelancer.headline)} · ${esc(x.freelancer.location)} · ${inr(x.freelancer.rate)}/hr · ${x.freelancer.stats.avgRating ? `<span style="color:var(--amber)">${x.freelancer.stats.avgRating.toFixed(1)} ★ (${x.freelancer.stats.reviews})</span>` : 'New'}</div></div>
      ${x.hasProposed ? '<span class="pill ok">Proposed</span>' : p.status === 'open' ? `<button class="btn ghost sm" data-act="invite" data-project="${p.id}" data-f="${x.freelancer.id}">Invite</button>` : ''}</div>
      <div style="margin:10px 0">${tags(x.freelancer.skills, x.matchedSkills)}</div><div class="why">✦ ${esc(x.why)}</div></div>`).join('')
    : empty('🔍', 'No matches yet', 'No freelancers share skills with this project. Try adding related skills.');
  const props = pr.proposals.length ? pr.proposals.map((x) => `
    <div class="list-item ${x.status === 'hired' ? 'hl' : ''}"><div class="row"><span class="avatar">${esc(initials(x.name))}</span>
      <div class="grow"><a href="#/user/${x.freelancer_id}" style="font-weight:700;color:inherit">${esc(x.name)}</a><div class="small muted">${esc(x.headline)}${x.stats.avgRating ? ` · <span style="color:var(--amber)">${x.stats.avgRating.toFixed(1)} ★</span>` : ''}</div></div>
      <span class="pill pri">${x.score}% match</span>${statusPill(x.status)}</div>
      <p style="margin:10px 0;white-space:pre-wrap">${esc(x.cover)}</p>
      <div class="row sp"><b>${inr(x.bid)} · ${x.weeks} week${x.weeks === 1 ? '' : 's'}</b>
      <div class="row"><button class="btn ghost sm" data-act="chat" data-project="${p.id}" data-f="${x.freelancer_id}" data-name="${esc(x.name)}">Message</button>
      ${p.status === 'open' ? `${x.status === 'shortlisted' ? '' : `<button class="btn ghost sm" data-act="shortlist" data-id="${x.id}">Shortlist</button>`}<button class="btn danger sm" data-act="reject" data-id="${x.id}">Decline</button>
      <button class="btn sm" data-act="hire" data-id="${x.id}" data-bid="${x.bid}" data-name="${esc(x.name)}">Hire</button>` : ''}</div></div></div>`).join('')
    : empty('📭', 'No relevant proposals yet', pr.hidden ? `${pr.hidden} low-relevance proposal${pr.hidden === 1 ? ' is' : 's are'} hidden.` : 'Invite top matches to get proposals faster.');
  const body = `${head}
    <div class="seg" role="tablist" style="margin-bottom:16px"><button class="${tab === 'matches' ? 'on' : ''}" data-act="tab" data-tab="matches" role="tab">AI matches (${m.matches.length})</button>
    <button class="${tab === 'proposals' ? 'on' : ''}" data-act="tab" data-tab="proposals" role="tab">Proposals (${pr.relevant} relevant of ${pr.total})</button></div>
    ${tab === 'matches' ? `<div class="stack">${matches}</div>` : `<div class="stack">${props}
      ${pr.hidden && !state.showAll ? `<button class="btn ghost" data-act="showall">Show ${pr.hidden} low-relevance proposal${pr.hidden === 1 ? '' : 's'} (below ${pr.threshold}% match)</button>` : state.showAll && pr.total > pr.relevant ? '<button class="btn ghost" data-act="hideall">Hide low-relevance proposals</button>' : ''}</div>`}`;
  mount(shell('Projects / ' + esc(p.title), body));
}

async function viewContracts() {
  mount(shell('Contracts', skeleton()));
  const { contracts } = await api('/contracts');
  mount(shell('Contracts', `<div class="page-h"><div><h1>Contracts</h1><p>Milestones, escrow and payments.</p></div></div><div class="stack">${contracts.length ? contracts.map((c) => `
    <a class="list-item" href="#/contract/${c.id}" style="display:block;color:inherit;text-decoration:none"><div class="row sp"><b>${esc(c.project.title)}</b>${statusPill(c.status)}</div>
    <div class="small muted" style="margin:4px 0 10px">${esc(me.role === 'client' ? c.freelancer.name : c.client.name)} · ${inr(c.total)} total · ${inr(c.summary.paid)} paid</div><div class="bar"><i style="width:${c.summary.progress}%"></i></div></a>`).join('')
    : empty('📄', 'No contracts yet', me.role === 'client' ? 'Hire a freelancer from a project to start a contract.' : 'Your contracts appear here once a client hires you.')}</div>`));
}

async function viewContract(id) {
  mount(shell('Contracts / …', skeleton()));
  const d = await api('/contracts/' + id);
  const c = d.contract;
  const isClient = me.id === c.client_id;
  const flow = ['pending', 'funded', 'submitted', 'paid'];
  const labels = ['Pending', 'Funded', 'Submitted', 'Paid'];
  const ms = d.milestones.map((m) => {
    const idx = flow.indexOf(m.status);
    const stepper = `<div class="stepper">${flow.map((s, i) => `<div class="step ${i < idx || m.status === 'paid' ? 'done' : ''} ${i === idx && m.status !== 'paid' ? 'cur' : ''}"><div class="dot">${i < idx || m.status === 'paid' ? '✓' : i + 1}</div>${i < flow.length - 1 ? '<div class="line"></div>' : ''}</div>`).join('')}</div>
      <div class="labels">${labels.map((l) => `<span>${l}</span>`).join('')}</div>`;
    let action = '';
    if (isClient && m.status === 'pending') action = `<button class="btn ghost sm" data-act="fund" data-id="${m.id}">Fund ${inr(m.amount)}</button>`;
    if (isClient && m.status === 'submitted') action = `<button class="btn sm" data-act="approve" data-id="${m.id}">Approve and release ${inr(m.amount)}</button>`;
    if (!isClient && m.status === 'funded') action = `<button class="btn sm" data-act="submitwork" data-id="${m.id}" data-title="${esc(m.title)}">Submit work</button>`;
    return `<div class="list-item"><div class="row sp"><b>${m.position}. ${esc(m.title)}</b><b>${inr(m.amount)}</b></div>${stepper}
      ${m.deliverable ? `<div class="small" style="margin-top:10px"><span class="muted">Deliverable:</span> ${esc(m.deliverable)}</div>` : ''}
      <div class="row sp" style="margin-top:10px">${statusPill(m.status)}${action}</div></div>`;
  }).join('');
  const myReview = d.reviews.find((r) => r.reviewer_id === me.id);
  const review = c.status !== 'completed' ? '' : myReview
    ? `<section class="card"><h2>Your review</h2><div style="color:var(--amber);font-size:18px">${stars(myReview.rating)}</div><p class="muted">${esc(myReview.comment)}</p></section>`
    : `<section class="card"><h2>Leave a review</h2><form data-form="review" data-contract="${c.id}" novalidate><div class="form-err" hidden></div>
        <div class="field"><label for="rt">Rating</label><select id="rt" name="rating"><option value="5">★★★★★ Excellent</option><option value="4">★★★★ Good</option><option value="3">★★★ Okay</option><option value="2">★★ Poor</option><option value="1">★ Bad</option></select></div>
        <div class="field"><label for="rc">Comment</label><textarea id="rc" name="comment" placeholder="How was the collaboration?"></textarea></div><button class="btn" type="submit">Submit review</button></form></section>`;
  const body = `<div class="page-h"><div><h1>${esc(c.project.title)}</h1><p>${esc(c.client.name)} (client) · ${esc(c.freelancer.name)} (freelancer) · ${statusPill(c.status)}</p></div>
      <a class="btn ghost" href="/api/contracts/${c.id}/invoice" target="_blank" rel="noopener">Invoice ↓</a></div>
    <div class="grid g2"><div class="stack">
      <section class="card"><div class="row sp"><h2 style="margin:0">Milestones</h2><b class="muted">${d.summary.progress}% complete</b></div>
        <p class="muted small" style="margin:4px 0 10px">${inr(c.total)} total · ${inr(d.summary.paid)} paid · ${inr(d.summary.escrow)} in escrow</p><div class="bar"><i style="width:${d.summary.progress}%"></i></div>
        <div class="stack" style="margin-top:16px">${ms}</div></section>
      ${review}
      <section class="card"><h2>Transactions</h2>${d.transactions.length ? `<table><thead><tr><th>Date</th><th>Type</th><th style="text-align:right">Amount</th></tr></thead><tbody>${d.transactions.map((t) => `<tr><td>${when(t.created_at)}</td><td>${t.type === 'escrow_deposit' ? 'Escrow deposit' : 'Released to freelancer'}</td><td style="text-align:right;font-weight:600">${inr(t.amount)}</td></tr>`).join('')}</tbody></table>` : empty('🧾', 'No transactions yet', 'Fund a milestone to begin.')}</section></div>
    <section class="card" style="align-self:start"><h2>Messages with ${esc(isClient ? c.freelancer.name : c.client.name)}</h2><div id="chat"></div></section></div>`;
  mount(shell('Contracts / ' + esc(c.project.title), body));
  startChat($('#chat'), c.project_id, isClient ? c.freelancer_id : null);
}

async function viewUser(id) {
  mount(shell('Profile', skeleton()));
  const d = await api('/users/' + id);
  const u = d.user;
  const total = d.reviews.length;
  const avg = total ? d.reviews.reduce((a, r) => a + r.rating, 0) / total : 0;
  mount(shell('Profile / ' + esc(u.name), `<div class="page-h"><div class="row"><span class="avatar" style="width:64px;height:64px;font-size:20px">${esc(initials(u.name))}</span>
    <div><h1>${esc(u.name)}</h1><p>${esc(u.headline || u.company || u.role)}${u.location ? ' · ' + esc(u.location) : ''}</p></div></div>${u.role === 'freelancer' ? `<span class="pill ${u.available ? 'ok' : ''}">${u.available ? 'Available now' : 'Busy'}</span>` : ''}</div>
    <div class="grid g2"><div class="stack"><section class="card"><h2>About</h2><p style="white-space:pre-wrap">${esc(u.bio || 'No bio yet.')}</p>${u.skills.length ? `<div style="margin-top:14px">${tags(u.skills)}</div>` : ''}</section>
    <section class="card"><h2>Reviews (${total})</h2><div class="stack">${total ? d.reviews.map((r) => `<div><div class="row sp"><b>${esc(r.reviewer)}</b><span style="color:var(--amber)">${stars(r.rating)}</span></div><p class="muted">${esc(r.comment)}</p></div>`).join('') : empty('⭐', 'No reviews yet', 'Reviews appear after a contract is completed.')}</div></section></div>
    <section class="card" style="align-self:start"><h2>Rating</h2><div style="font-size:34px;font-weight:800">${avg ? avg.toFixed(1) : '–'} <span style="font-size:16px;color:var(--amber)">${avg ? stars(avg) : ''}</span></div>
      <div class="stack" style="margin-top:12px">${d.breakdown.map((b) => `<div class="row small"><span style="width:22px">${b.star}★</span><div class="bar grow"><i style="width:${total ? (b.count / total) * 100 : 0}%"></i></div><span style="width:20px;text-align:right">${b.count}</span></div>`).join('')}</div>
      ${u.role === 'freelancer' ? `<p class="muted" style="margin-top:14px">${inr(u.rate)}/hr · ${u.stats.completed} of ${u.stats.total} contracts completed</p>` : ''}</section></div>`));
}

async function viewProfile() {
  const { user: u } = await api('/me');
  mount(shell('My profile', `<div class="page-h"><div><h1>My profile</h1><p>Better profiles get better matches.</p></div><a class="btn ghost" href="#/user/${u.id}">View public profile</a></div>
    <form class="card" data-form="profile" novalidate style="max-width:680px"><div class="form-err" hidden></div>
      <div class="field"><label for="hl">Headline</label><input id="hl" name="headline" value="${esc(u.headline)}"></div>
      <div class="field"><label for="bi">Bio</label><textarea id="bi" name="bio">${esc(u.bio)}</textarea></div>
      <div class="field"><label for="ps">Skills (comma separated)</label><input id="ps" name="skills" value="${esc(u.skills.join(', '))}"></div>
      <div class="grid g2e"><div class="field"><label for="pr">Hourly rate (₹)</label><input id="pr" name="rate" type="number" min="0" value="${u.rate}"></div>
      <div class="field"><label for="pa">Availability</label><select id="pa" name="available"><option value="1" ${u.available ? 'selected' : ''}>Available now</option><option value="0" ${!u.available ? 'selected' : ''}>Busy</option></select></div></div>
      <button class="btn" type="submit">Save profile</button></form>`));
}

const forbiddenView = () => mount(shell('Not allowed', empty('🚫', 'You can’t view this page', 'This page belongs to another account.', '<a class="btn" href="#/">Back to dashboard</a>')));
const notFoundView = () => mount(`<div class="err-page"><div><div style="font-size:64px;font-weight:800;color:var(--primary)">404</div><h1>Page not found</h1><p class="muted" style="margin:6px 0 18px">That page does not exist.</p><a class="btn" href="#/">Go home</a></div></div>`);

/* ---------- chat ---------- */
function startChat(el, projectId, withId, poll = true) {
  if (!el) return;
  const q = withId ? `?with=${withId}` : '';
  el.innerHTML = `<div class="chat"><div class="msgs" id="msgs" aria-live="polite"></div><form id="chatForm"><input name="body" placeholder="Type a message…" aria-label="Message" autocomplete="off"><button class="btn" type="submit">Send</button></form></div>`;
  const box = $('#msgs', el);
  let last = -1;
  async function load() {
    try {
      const d = await api(`/projects/${projectId}/messages${q}`);
      const sig = d.messages.length + ':' + (d.messages.at(-1)?.id || 0);
      if (sig === last) return;
      last = sig;
      box.innerHTML = d.messages.length ? d.messages.map((m) => `<div class="bub ${m.sender_id === me.id ? 'me' : ''}">${esc(m.body)}<time>${clock(m.created_at)}</time></div>`).join('')
        : '<div class="empty">No messages yet. Say hello 👋</div>';
      box.scrollTop = box.scrollHeight;
    } catch (e) { box.innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
  }
  $('#chatForm', el).onsubmit = async (ev) => {
    ev.preventDefault();
    const inp = ev.target.body;
    const body = inp.value.trim();
    if (!body) return;
    inp.value = '';
    try { await api(`/projects/${projectId}/messages${q}`, { method: 'POST', body: { body, with: withId } }); last = -1; load(); } catch (e) { toast(e.message, true); inp.value = body; }
  };
  load();
  if (poll) { const t = setInterval(load, 4000); (el.closest('.modal') ? (clearInterval(modalTimer), modalTimer = t) : timers.push(t)); }
}

/* ---------- modals ---------- */
function openModal(html) {
  closeModal();
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) closeModal(); });
  document.body.append(bg);
  const first = $('input, textarea, button', bg);
  if (first) first.focus();
  return bg;
}
function closeModal() { clearInterval(modalTimer); document.querySelectorAll('.modal-bg').forEach((m) => m.remove()); }
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

function hireModal(id, bid, name) {
  const a = Math.round(bid * 0.3), b = Math.round(bid * 0.5), c = bid - a - b;
  const row = (t, v) => `<div class="row ms-row" style="margin-bottom:8px"><input name="mt" value="${esc(t)}" aria-label="Milestone title" class="grow"><input name="ma" type="number" min="1" value="${v}" aria-label="Amount" style="width:120px"><button type="button" class="btn ghost sm" data-act="rmrow" aria-label="Remove">✕</button></div>`;
  const bg = openModal(`<h2>Hire ${esc(name)}</h2><p class="muted" style="margin-bottom:14px">Agreed bid: <b>${inr(bid)}</b>. Split it into milestones. You fund each one into escrow and release it when you approve the work.</p>
    <form data-form="hire" data-id="${id}" data-bid="${bid}" novalidate><div class="form-err" hidden></div><div id="rows">${row('Design and planning', a)}${row('Build', b)}${row('Testing and launch', c)}</div>
    <div class="row sp" style="margin:6px 0 16px"><button type="button" class="btn ghost sm" data-act="addrow">＋ Add milestone</button><b id="msTotal"></b></div>
    <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="closemodal">Cancel</button><button class="btn" type="submit">Create contract</button></div></form>`);
  bg.dataset.rowTpl = row('', '');
  const upd = () => {
    const sum = [...bg.querySelectorAll('input[name=ma]')].reduce((s, i) => s + (parseInt(i.value, 10) || 0), 0);
    const t = $('#msTotal', bg);
    t.textContent = `Total ${inr(sum)} of ${inr(bid)}`;
    t.style.color = sum === Number(bid) ? 'var(--green)' : 'var(--red)';
  };
  bg.addEventListener('input', upd);
  bg.addEventListener('click', (e) => { if (e.target.closest('[data-act=addrow],[data-act=rmrow]')) setTimeout(upd); });
  upd();
}

/* ---------- actions (event delegation) ---------- */
const csv = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);
const fd = (form) => Object.fromEntries(new FormData(form));
const showErr = (form, msg) => { const e = $('.form-err', form); if (e) { e.textContent = msg; e.hidden = false; e.scrollIntoView({ block: 'nearest' }); } };

const actions = {
  closemodal: () => closeModal(),
  logout: async (el) => busy(el, async () => { await api('/auth/logout', { method: 'POST' }); me = null; location.hash = '#/login'; route(); }),
  async bell() {
    const drop = $('#drop');
    if (!drop.hidden) { drop.hidden = true; return; }
    drop.hidden = false;
    drop.innerHTML = '<div class="empty small">Loading…</div>';
    try {
      const d = await api('/notifications');
      drop.innerHTML = d.notifications.length ? d.notifications.map((n) => `<a href="${esc(n.link || '#/')}" class="${n.read ? '' : 'unread'}">${esc(n.text)}<div class="small muted">${when(n.created_at)}</div></a>`).join('') : '<div class="empty small">You are all caught up 🎉</div>';
      if (d.unread) { await api('/notifications/read', { method: 'POST' }); const b = $('#bellN'); if (b) b.hidden = true; }
    } catch (e) { drop.innerHTML = `<div class="empty small">${esc(e.message)}</div>`; }
  },
  invite: (el) => busy(el, async () => { await api(`/projects/${el.dataset.project}/invite`, { method: 'POST', body: { freelancerId: el.dataset.f } }); el.textContent = 'Invited ✓'; el.disabled = true; toast('Invitation sent'); }),
  tab: (el) => { state.tab = el.dataset.tab; route(); },
  showall: () => { state.showAll = true; route(); },
  hideall: () => { state.showAll = false; route(); },
  clearfilters: () => { state.filters = {}; route(); },
  shortlist: (el) => busy(el, async () => { await api('/proposals/' + el.dataset.id, { method: 'PATCH', body: { status: 'shortlisted' } }); toast('Shortlisted'); route(); }),
  reject: (el) => busy(el, async () => { await api('/proposals/' + el.dataset.id, { method: 'PATCH', body: { status: 'rejected' } }); toast('Proposal declined'); route(); }),
  hire: (el) => hireModal(el.dataset.id, Number(el.dataset.bid), el.dataset.name),
  addrow: () => { const bg = $('.modal-bg'); $('#rows', bg).insertAdjacentHTML('beforeend', bg.dataset.rowTpl); },
  rmrow: (el) => { if (document.querySelectorAll('.ms-row').length > 1) el.closest('.ms-row').remove(); },
  chat: (el) => {
    const bg = openModal(`<h2>Chat with ${esc(el.dataset.name)}</h2><div id="mchat"></div><div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn ghost" data-act="closemodal">Close</button></div>`);
    startChat($('#mchat', bg), el.dataset.project, el.dataset.f);
  },
  fund: (el) => busy(el, async () => { await api(`/milestones/${el.dataset.id}/fund`, { method: 'POST' }); toast('Milestone funded and held in escrow'); route(); }),
  approve: (el) => busy(el, async () => { await api(`/milestones/${el.dataset.id}/approve`, { method: 'POST' }); toast('Approved. Payment released.'); route(); }),
  submitwork: (el) => {
    openModal(`<h2>Submit “${esc(el.dataset.title)}”</h2><form data-form="submitwork" data-id="${el.dataset.id}" novalidate><div class="form-err" hidden></div>
      <div class="field"><label for="dv">What are you delivering?</label><textarea id="dv" name="deliverable" placeholder="Describe the work and paste any links"></textarea></div>
      <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-act="closemodal">Cancel</button><button class="btn" type="submit">Submit for review</button></div></form>`);
  },
};

const forms = {
  async login(f) { const d = await api('/auth/login', { method: 'POST', body: fd(f) }); me = d.user; location.hash = '#/'; route(); },
  async register(f) { const v = fd(f); v.skills = csv(v.skills); const d = await api('/auth/register', { method: 'POST', body: v }); me = d.user; toast('Welcome to TalentMatch!'); location.hash = me.role === 'freelancer' ? '#/profile' : '#/new'; route(); },
  async project(f) { const v = fd(f); v.skills = csv(v.skills); const d = await api('/projects', { method: 'POST', body: v }); toast('Project posted. Here are your best matches.'); state.tab = 'matches'; location.hash = '#/project/' + d.project.id; },
  async proposal(f) { const d = await api(`/projects/${f.dataset.project}/proposals`, { method: 'POST', body: fd(f) }); toast(`Proposal sent (${d.score}% match)`); route(); },
  async hire(f) {
    const titles = [...f.querySelectorAll('input[name=mt]')].map((i) => i.value);
    const amounts = [...f.querySelectorAll('input[name=ma]')].map((i) => parseInt(i.value, 10) || 0);
    const milestones = titles.map((title, i) => ({ title, amount: amounts[i] }));
    const d = await api(`/proposals/${f.dataset.id}/hire`, { method: 'POST', body: { milestones } });
    closeModal(); toast('Contract created'); location.hash = '#/contract/' + d.contractId;
  },
  async submitwork(f) { await api(`/milestones/${f.dataset.id}/submit`, { method: 'POST', body: fd(f) }); closeModal(); toast('Work submitted for review'); route(); },
  async review(f) { await api(`/contracts/${f.dataset.contract}/reviews`, { method: 'POST', body: fd(f) }); toast('Thanks for your review'); route(); },
  async profile(f) { const v = fd(f); v.skills = csv(v.skills); v.available = v.available === '1'; const d = await api('/me', { method: 'PATCH', body: v }); me = d.user; toast('Profile saved'); },
  async filters(f) { state.filters = fd(f); route(); },
};

document.addEventListener('click', (e) => {
  const go = e.target.closest('[data-go]');
  if (go) { location.hash = go.dataset.go; return; }
  const demo = e.target.closest('[data-demo]');
  if (demo) { $('#email').value = demo.dataset.demo; $('#password').value = 'Demo@123'; $('form[data-form=login]').requestSubmit(); return; }
  const el = e.target.closest('[data-act]');
  if (el && actions[el.dataset.act]) { e.preventDefault(); actions[el.dataset.act](el); return; }
  if (!e.target.closest('.top-r')) { const d = $('#drop'); if (d) d.hidden = true; }
});

document.addEventListener('submit', async (e) => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const handler = forms[f.dataset.form];
  const btn = $('button[type=submit]', f);
  const err = $('.form-err', f);
  if (err) err.hidden = true;
  await busy(btn, async () => { try { await handler(f); } catch (ex) { if (err) showErr(f, ex.message); else throw ex; } });
});

/* ---------- router ---------- */
const publicRoutes = ['#/login', '#/register'];
const routes = [
  [/^#\/login$/, () => viewAuth('login')], [/^#\/register$/, () => viewAuth('register')],
  [/^#\/?$/, viewDashboard], [/^#\/new$/, viewNewProject], [/^#\/projects$/, viewProjects],
  [/^#\/project\/(\d+)$/, viewProject], [/^#\/contracts$/, viewContracts], [/^#\/contract\/(\d+)$/, viewContract],
  [/^#\/user\/(\d+)$/, viewUser], [/^#\/profile$/, viewProfile],
];

async function route() {
  clearTimers(); closeModal();
  const hash = location.hash || '#/';
  if (!me && !publicRoutes.includes(hash)) { location.hash = '#/login'; return; }
  if (me && publicRoutes.includes(hash)) { location.hash = '#/'; return; }
  for (const [re, fn] of routes) {
    const m = hash.match(re);
    if (!m) continue;
    try { await fn(...m.slice(1)); if (me) refreshBell(); } catch (e) {
      if (e.status === 401) { me = null; location.hash = '#/login'; return; }
      const retry = '<button class="btn" data-act="retry">Try again</button>';
      actions.retry = () => route();
      const view = e.status === 404 ? empty('🔎', 'Not found', e.message, '<a class="btn" href="#/">Go home</a>')
        : e.status === 403 ? empty('🚫', 'Not allowed', e.message, '<a class="btn" href="#/">Back to dashboard</a>')
        : empty('⚠️', 'Something went wrong', e.message, retry);
      mount(me ? shell('Error', view) : `<div class="err-page">${view}</div>`);
    }
    return;
  }
  notFoundView();
}

window.addEventListener('hashchange', route);
(async function init() {
  try { me = (await api('/me')).user; } catch { me = null; }
  route();
})();

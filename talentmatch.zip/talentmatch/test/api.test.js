process.env.DB_PATH = ':memory:';
process.env.AUTH_SECRET = 'test-secret';

const test = require('node:test');
const assert = require('node:assert/strict');
const app = require('../src/server');
const { scoreMatch } = require('../src/matching');

let server, base;
test.before(() => new Promise((resolve) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; resolve(); }); }));
test.after(() => server.close());

function client() {
  let cookie = '';
  return async (path, { method = 'GET', body } = {}) => {
    const res = await fetch(base + '/api' + path, {
      method, headers: { 'Content-Type': 'application/json', cookie }, body: body ? JSON.stringify(body) : undefined,
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const type = res.headers.get('content-type') || '';
    return { status: res.status, data: type.includes('json') ? await res.json() : await res.text() };
  };
}

test('matching: more skill overlap scores higher and explains why', () => {
  const project = { skills: ['React', 'Node.js', 'Figma'], budget: 80000 };
  const strong = scoreMatch(project, { skills: ['react', 'node.js', 'figma'], rate: 1000, available: true }, { avgRating: 4.8, total: 5, completed: 5 });
  const weak = scoreMatch(project, { skills: ['react'], rate: 1000, available: true }, { avgRating: 4.8, total: 5, completed: 5 });
  assert.ok(strong.score > weak.score);
  assert.deepEqual(weak.missingSkills, ['node.js', 'figma']);
  assert.match(strong.why, /3 of 3/);
});

test('auth: validates input, rejects bad passwords, protects routes', async () => {
  const api = client();
  assert.equal((await api('/projects')).status, 401);
  assert.equal((await api('/auth/register', { method: 'POST', body: { role: 'client', name: 'A', email: 'bad', password: 'Password1' } })).status, 400);
  assert.equal((await api('/auth/register', { method: 'POST', body: { role: 'client', name: 'A', email: 'a@x.com', password: 'short' } })).status, 400);
  assert.equal((await api('/auth/register', { method: 'POST', body: { role: 'client', name: 'A', email: 'a@x.com', password: 'Password1' } })).status, 201);
  const me = (await api('/me')).data.user;
  assert.equal(me.name, 'A');
  assert.equal(me.role, 'client');
  assert.equal(me.email, undefined); // emails are never exposed in API responses
  assert.equal(me.password_hash, undefined);
  const other = client();
  assert.equal((await other('/auth/login', { method: 'POST', body: { email: 'a@x.com', password: 'wrong-password' } })).status, 401);
});

test('full hiring flow: project -> match -> proposal -> hire -> escrow -> review', async () => {
  const cl = client(); const fl = client(); const stranger = client();
  await cl('/auth/register', { method: 'POST', body: { role: 'client', name: 'Cora Client', email: 'cora@x.com', password: 'Password1' } });
  const f = await fl('/auth/register', { method: 'POST', body: { role: 'freelancer', name: 'Finn Freelancer', email: 'finn@x.com', password: 'Password1', skills: ['React', 'Figma'], rate: 800 } });
  await stranger('/auth/register', { method: 'POST', body: { role: 'client', name: 'Sam Stranger', email: 'sam@x.com', password: 'Password1' } });

  // validation
  assert.equal((await cl('/projects', { method: 'POST', body: { title: 'x' } })).status, 400);
  assert.equal((await fl('/projects', { method: 'POST', body: { title: 'Valid title', description: 'A long enough description here.', skills: ['React'], budget: 1000 } })).status, 403);

  const created = await cl('/projects', { method: 'POST', body: { title: 'Storefront redesign', description: 'Redesign the storefront with a faster checkout.', skills: ['React', 'Figma'], budget: 60000 } });
  assert.equal(created.status, 201);
  const pid = created.data.project.id;

  // AI-ranked matches include the freelancer
  const matches = await cl(`/projects/${pid}/matches`);
  assert.equal(matches.data.matches[0].freelancer.id, f.data.user.id);
  assert.ok(matches.data.matches[0].score >= 60);
  assert.equal((await stranger(`/projects/${pid}/matches`)).status, 403);

  // freelancer sees it as recommended, sends a proposal (only once)
  const list = await fl('/projects');
  assert.equal(list.data.projects[0].id, pid);
  const body = { cover: 'I have built several storefronts and can start right away.', bid: 50000, weeks: 4 };
  const prop = await fl(`/projects/${pid}/proposals`, { method: 'POST', body });
  assert.equal(prop.status, 201);
  assert.equal((await fl(`/projects/${pid}/proposals`, { method: 'POST', body })).status, 400);

  const proposals = await cl(`/projects/${pid}/proposals`);
  assert.equal(proposals.data.proposals.length, 1);
  const proposalId = proposals.data.proposals[0].id;

  // messaging works between the two parties and not for strangers
  assert.equal((await cl(`/projects/${pid}/messages`, { method: 'POST', body: { body: 'Hello!', with: f.data.user.id } })).status, 201);
  const thread = await fl(`/projects/${pid}/messages`);
  assert.equal(thread.data.messages[0].body, 'Hello!');
  assert.equal((await stranger(`/projects/${pid}/messages?with=${f.data.user.id}`)).status, 403);

  // hiring: milestone total must equal the bid
  assert.equal((await cl(`/proposals/${proposalId}/hire`, { method: 'POST', body: { milestones: [{ title: 'All', amount: 100 }] } })).status, 400);
  const hired = await cl(`/proposals/${proposalId}/hire`, { method: 'POST', body: { milestones: [{ title: 'Design', amount: 20000 }, { title: 'Build', amount: 30000 }] } });
  assert.equal(hired.status, 201);
  const cid = hired.data.contractId;

  let detail = (await cl(`/contracts/${cid}`)).data;
  const [m1, m2] = detail.milestones;
  assert.equal(detail.contract.project.status, 'in_progress');

  // escrow rules and permissions
  assert.equal((await fl(`/milestones/${m1.id}/fund`, { method: 'POST' })).status, 403);
  assert.equal((await cl(`/milestones/${m1.id}/submit`, { method: 'POST', body: { deliverable: 'nope nope' } })).status, 403);
  assert.equal((await cl(`/milestones/${m1.id}/approve`, { method: 'POST' })).status, 400); // not submitted yet
  assert.equal((await fl(`/milestones/${m1.id}/submit`, { method: 'POST', body: { deliverable: 'too early' } })).status, 400); // not funded yet
  assert.equal((await stranger(`/contracts/${cid}`)).status, 403);

  for (const m of [m1, m2]) {
    assert.equal((await cl(`/milestones/${m.id}/fund`, { method: 'POST' })).status, 200);
    detail = (await cl(`/contracts/${cid}`)).data;
    assert.equal(detail.summary.escrow > 0, true);
    assert.equal((await fl(`/milestones/${m.id}/submit`, { method: 'POST', body: { deliverable: 'Delivered, see link' } })).status, 200);
    assert.equal((await cl(`/milestones/${m.id}/approve`, { method: 'POST' })).status, 200);
  }

  detail = (await cl(`/contracts/${cid}`)).data;
  assert.equal(detail.contract.status, 'completed');
  assert.equal(detail.summary.paid, 50000);
  assert.equal(detail.summary.escrow, 0);
  assert.equal(detail.transactions.length, 4);
  assert.match((await cl(`/contracts/${cid}/invoice`)).data, /Total: ₹50000/);

  // two-way reviews, one per person
  assert.equal((await cl(`/contracts/${cid}/reviews`, { method: 'POST', body: { rating: 5, comment: 'Great' } })).status, 201);
  assert.equal((await cl(`/contracts/${cid}/reviews`, { method: 'POST', body: { rating: 4 } })).status, 400);
  assert.equal((await fl(`/contracts/${cid}/reviews`, { method: 'POST', body: { rating: 5, comment: 'Lovely client' } })).status, 201);
  const profile = await cl(`/users/${f.data.user.id}`);
  assert.equal(profile.data.user.stats.avgRating, 5);
  assert.equal(profile.data.reviews.length, 1);

  // dashboards reflect the work
  const dash = await fl('/dashboard');
  assert.equal(dash.data.stats.earned, 50000);
  const cdash = await cl('/dashboard');
  assert.equal(cdash.data.stats.spent, 50000);
});

test('unknown api route returns JSON 404, SPA fallback serves HTML', async () => {
  const res = await fetch(base + '/api/nope');
  assert.equal(res.status, 404);
  assert.ok((await res.json()).error);
  const page = await fetch(base + '/some/page');
  assert.match(await page.text(), /TalentMatch/);
});
